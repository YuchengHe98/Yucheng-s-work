package uk.ac.shef.oak.com4510.viewmodel;

import uk.ac.shef.oak.com4510.view.VisitActivity;

public class VisitViewModel {

    private VisitActivity visitActivity;

}
